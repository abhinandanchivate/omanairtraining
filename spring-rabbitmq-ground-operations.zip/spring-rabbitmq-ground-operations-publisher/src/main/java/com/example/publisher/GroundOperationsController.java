package com.example.publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/ground-operations")
public class GroundOperationsController {
    @Autowired
    private GroundOperationsPublisher publisher;

    @PostMapping("/publish")
    public String publishOperation(@RequestParam String task) {
        publisher.publishMessage(task);
        return "Published operation: " + task;
    }
}