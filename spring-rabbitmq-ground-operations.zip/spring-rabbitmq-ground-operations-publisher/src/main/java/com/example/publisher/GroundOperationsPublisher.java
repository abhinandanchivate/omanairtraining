package com.example.publisher;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GroundOperationsPublisher {
    @Autowired
    private RabbitTemplate rabbitTemplate;

    public void publishMessage(String operation) {
        String message = "{"task": "" + operation + ""}";
        rabbitTemplate.convertAndSend("ground_operations", "ground_operation", message);
        System.out.println("Published message: " + message);
    }
}