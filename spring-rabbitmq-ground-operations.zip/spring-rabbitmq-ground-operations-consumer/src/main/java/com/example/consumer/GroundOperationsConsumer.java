package com.example.consumer;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class GroundOperationsConsumer {
    @RabbitListener(queues = "ground_queue")
    public void receiveMessage(String message) {
        System.out.println("Received Message: " + message);
    }
}